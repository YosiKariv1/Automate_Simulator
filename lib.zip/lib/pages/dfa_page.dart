import 'package:flutter/material.dart';
import 'package:myapp/dfa_info/dfa_info.dart';
import 'package:myapp/dfa_info/welcome_popup.dart';
import 'package:myapp/pages/widgets/editor_widget.dart';
import 'package:myapp/pages/widgets/regx_widget.dart';

class DfaPage extends StatelessWidget {
  const DfaPage({super.key});

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance
        .addPostFrameCallback((_) => showWelcomeDialog(context));

    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text(
            'DFA Simulator',
            style: TextStyle(
                fontWeight: FontWeight.bold, fontSize: 50, color: Colors.white),
          ),
        ),
        backgroundColor: Colors.blueGrey[900],
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blueGrey[700]!, Colors.blueGrey[900]!],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: LayoutBuilder(
          builder: (context, constraints) {
            bool isWideScreen = constraints.maxWidth > 800;

            return Flex(
              direction: isWideScreen ? Axis.horizontal : Axis.vertical,
              children: [
                buildEditorPanel(),
                buildRightPanel(isWideScreen),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget buildEditorPanel() {
    return Expanded(
      flex: 3,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16.0),
          child: Container(
            height: double.infinity,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16.0),
              boxShadow: const [
                BoxShadow(color: Colors.black12, blurRadius: 10.0),
              ],
            ),
            child: const EditorWidget(),
          ),
        ),
      ),
    );
  }

  Widget buildRightPanel(bool isWideScreen) {
    return Expanded(
      flex: 1,
      child: Column(
        children: [
          buildSmallContainer(),
          buildInfoPanel(),
        ],
      ),
    );
  }

  Widget buildSmallContainer() {
    return Container(
      width: double.infinity,
      height: 200,
      margin: const EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        color: Colors.blueGrey[50],
        borderRadius: BorderRadius.circular(20.0),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 10.0),
        ],
      ),
      child: const RegxWidget(),
    );
  }

  Widget buildInfoPanel() {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.blueGrey[50],
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: const [
              BoxShadow(color: Colors.black12, blurRadius: 10.0),
            ],
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(10.0),
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: Colors.blueGrey,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(16.0),
                    topRight: Radius.circular(16.0),
                  ),
                ),
                child: Row(
                  children: [
                    Text(
                      'DFA Information',
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.blueGrey[50]),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () {},
                      icon:
                          Icon(Icons.info_outline, color: Colors.blueGrey[50]),
                    ),
                  ],
                ),
              ),
              const Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(8.0),
                  child: DfaInfoWidget(), // Updated widget name
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
