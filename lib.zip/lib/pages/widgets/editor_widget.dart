import 'package:flutter/material.dart';
import 'package:myapp/classes/node_class.dart';
import 'package:myapp/widgets/automaton_widget.dart';
import 'package:provider/provider.dart';
import 'package:myapp/classes/automaton_class.dart';

class EditorWidget extends StatefulWidget {
  const EditorWidget({super.key});

  @override
  EditorWidgetState createState() => EditorWidgetState();
}

class EditorWidgetState extends State<EditorWidget> {
  late Automaton automaton;
  TransformationController transformationController =
      TransformationController();
  bool isAnimating = false;

  @override
  void initState() {
    super.initState();
    automaton = Provider.of<Automaton>(context, listen: false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo[50],
      body: Stack(
        children: [
          InteractiveViewer(
            transformationController: transformationController,
            boundaryMargin: const EdgeInsets.all(20),
            minScale: 0.1,
            maxScale: 5.0,
            constrained: false,
            child: SizedBox(
              width: MediaQuery.of(context).size.width * 3,
              height: MediaQuery.of(context).size.height * 3,
              child: const AutomatonWidget(),
            ),
          ),
          Positioned(
            right: 16,
            bottom: 40,
            child: FloatingActionButton(
              onPressed: () => {},
              child: const Icon(Icons.center_focus_strong),
            ),
          ),
        ],
      ),
      bottomNavigationBar: buildButtonBar(),
    );
  }

  Widget buildButtonBar() {
    return Container(
      color: Colors.transparent,
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          buildButton(
            label: 'Add Node',
            color: Colors.blueGrey[700]!,
            icon: Icons.add,
            onPressed: addNode,
          ),
          buildButton(
            label: 'Play',
            color: Colors.green,
            icon: Icons.play_arrow,
            onPressed: playAutomaton,
          ),
          buildButton(
            label: 'Delete Node',
            color: Colors.blueGrey[900]!,
            icon: Icons.delete,
            onPressed: automaton.removeNode,
          ),
        ],
      ),
    );
  }

  Widget buildButton({
    required String label,
    required Color color,
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        foregroundColor: Colors.white,
        backgroundColor: color,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        elevation: 10,
        shadowColor: Colors.black.withOpacity(0.3),
      ),
      icon: Icon(icon, size: 24),
      label: Text(
        label,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  void addNode() {
    Size viewportSize = MediaQuery.of(context).size;
    double centerX = viewportSize.width / 2;
    double centerY = viewportSize.height / 2;

    automaton.addNode(Node(
      name: 'Q${automaton.nodes.length}',
      position: Offset(centerX, centerY),
      isStart: automaton.nodes.isEmpty,
    ));
  }

  void playAutomaton() async {
    // need to add for simulation
  }
}
