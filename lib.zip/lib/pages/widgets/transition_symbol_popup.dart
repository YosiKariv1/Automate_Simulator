import 'package:flutter/material.dart';

class TransitionSymbolPopup extends StatefulWidget {
  final String alphabet;
  final Set<String> initialSymbols;

  const TransitionSymbolPopup({
    Key? key,
    required this.alphabet,
    required this.initialSymbols,
  }) : super(key: key);

  @override
  _TransitionSymbolPopupState createState() => _TransitionSymbolPopupState();
}

class _TransitionSymbolPopupState extends State<TransitionSymbolPopup> {
  late Set<String> selectedSymbols;

  @override
  void initState() {
    super.initState();
    selectedSymbols = Set.from(widget.initialSymbols);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.indigo[50],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
      ),
      title: Center(
        child: Text(
          "בחר סימבולים למעבר",
          style: TextStyle(
            color: Colors.indigo[900],
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: TextEditingController(text: selectedSymbols.join(', ')),
            readOnly: true,
            textAlign: TextAlign.center,
            decoration: InputDecoration(
              labelText: 'סימבולים שנבחרו',
              labelStyle: TextStyle(color: Colors.indigo[700]),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15.0),
              ),
              prefixIcon: const Icon(Icons.label, color: Colors.indigo),
            ),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: widget.alphabet.split('').map((letter) {
              return ElevatedButton(
                style: ElevatedButton.styleFrom(
                  foregroundColor: selectedSymbols.contains(letter)
                      ? Colors.white
                      : Colors.black,
                  backgroundColor: selectedSymbols.contains(letter)
                      ? Colors.blue
                      : Colors.grey[200],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  minimumSize: const Size(48, 48),
                ),
                onPressed: () {
                  setState(() {
                    if (selectedSymbols.contains(letter)) {
                      selectedSymbols.remove(letter);
                    } else {
                      selectedSymbols.add(letter);
                    }
                  });
                },
                child: Text(letter, style: const TextStyle(fontSize: 18)),
              );
            }).toList(),
          ),
        ],
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(null),
          style: TextButton.styleFrom(
            foregroundColor: Colors.red,
            textStyle: const TextStyle(fontSize: 16),
          ),
          child: const Text('ביטול'),
        ),
        ElevatedButton.icon(
          icon: const Icon(Icons.check, color: Colors.white),
          label: const Text('אישור'),
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: Colors.indigo,
            textStyle: const TextStyle(fontSize: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
          ),
          onPressed: selectedSymbols.isNotEmpty
              ? () => Navigator.of(context).pop(selectedSymbols)
              : null,
        ),
      ],
    );
  }
}
