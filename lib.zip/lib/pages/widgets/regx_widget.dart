import 'package:flutter/material.dart';
import 'package:myapp/classes/automaton_class.dart';
import 'package:myapp/dfa_info/regex_info.dart';
import 'package:provider/provider.dart';

class RegxWidget extends StatefulWidget {
  const RegxWidget({Key? key}) : super(key: key);

  @override
  RegxWidgetState createState() => RegxWidgetState();
}

class RegxWidgetState extends State<RegxWidget> {
  late Automaton automatonModel;
  bool showInputField = false;
  final TextEditingController textController = TextEditingController();
  String inputText = "";

  @override
  void initState() {
    super.initState();
    automatonModel = Provider.of<Automaton>(context, listen: false);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(8.0),
          width: double.infinity,
          decoration: const BoxDecoration(
            color: Colors.blueGrey,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16.0),
              topRight: Radius.circular(16.0),
            ),
          ),
          child: Row(
            children: [
              const Text(
                'Regular Expression',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const Spacer(),
              IconButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return const RegexInfoPopup();
                    },
                  );
                },
                icon: Icon(Icons.info_outline, color: Colors.blueGrey[50]),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Expanded(
          child: Center(
            child: showInputField
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 200,
                        height: 50,
                        child: TextField(
                          controller: textController,
                          decoration: const InputDecoration(
                            hintText: 'Enter regular expression',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      const SizedBox(height: 5),
                      ElevatedButton(
                        onPressed: () {
                          setState(() {
                            inputText = textController.text;
                            automatonModel.regularExp = inputText;
                            showInputField = false;
                          });
                        },
                        style: ElevatedButton.styleFrom(
                          foregroundColor: Colors.white,
                          backgroundColor: Colors.blueGrey[700],
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text('Submit'),
                      ),
                    ],
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        inputText.isEmpty ? 'No expression entered' : inputText,
                        style: const TextStyle(fontSize: 18),
                      ),
                      const Spacer(),
                      ElevatedButton(
                        onPressed: () {
                          setState(() {
                            showInputField = true;
                          });
                        },
                        style: ElevatedButton.styleFrom(
                          foregroundColor: Colors.white,
                          backgroundColor: Colors.blueGrey[700],
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text('Enter Expression'),
                      ),
                      const SizedBox(height: 10),
                    ],
                  ),
          ),
        ),
      ],
    );
  }
}
