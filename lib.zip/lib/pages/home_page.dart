import 'package:flutter/material.dart';
import 'package:myapp/pages/dfa_page.dart';
import 'package:myapp/pages/widgets/simulator_card.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blueGrey[700]!, Colors.blueGrey[900]!],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 100),
                  buildHeaderText(),
                  const SizedBox(height: 50),
                  buildSimulatorCardsLayout(context),
                  const SizedBox(height: 20),
                  buildFooterText(),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget buildHeaderText() {
    return const Center(
      child: Column(
        children: [
          Text(
            'Welcome to the Educational Automaton Simulator',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 10),
          Text(
            'Learn and Explore Various Automaton Models',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 20, color: Colors.white70),
          ),
          SizedBox(height: 20),
          Text(
            'Choose a Simulator:',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSimulatorCardsLayout(BuildContext context) {
    return Wrap(
      spacing: 20,
      runSpacing: 20,
      alignment: WrapAlignment.center,
      children: buildSimulatorCards(context),
    );
  }

  List<Widget> buildSimulatorCards(BuildContext context) {
    return [
      SimulatorCard(
        title: 'DFA Simulator',
        placeholderIcon: Icons.developer_board,
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const DfaPage(),
            ),
          );
        },
      ),
      SimulatorCard(
        title: 'PDA Simulator',
        placeholderIcon: Icons.memory,
        onTap: () {
          // Add navigation when PDA simulator is implemented
        },
      ),
      SimulatorCard(
        title: 'Turing Machine Simulator',
        placeholderIcon: Icons.computer,
        onTap: () {
          // Add navigation when Turing Machine simulator is implemented
        },
      ),
    ];
  }

  Widget buildFooterText() {
    return const Padding(
      padding: EdgeInsets.all(16.0),
      child: Text(
        'This simulator helps you understand the concepts of different automaton models. Choose a simulator to get started.',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 16, color: Colors.white70),
      ),
    );
  }
}
