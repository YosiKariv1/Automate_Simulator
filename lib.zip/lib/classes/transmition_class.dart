import 'package:flutter/material.dart';
import 'package:myapp/classes/node_class.dart';

class Transition extends ChangeNotifier {
  Node from;
  Node to;
  Set<String> symbol;
  Offset midPoint;
  bool isHighlighted = false;

  Transition({
    required this.from,
    required this.to,
    required this.symbol,
  }) : midPoint = Offset.zero {
    from.addListener(onNodeChanged);
    to.addListener(onNodeChanged);
    calculateMidPoint();
  }

  void onNodeChanged() {
    calculateMidPoint();
    notifyListeners();
  }

  Offset get fromPosition => from.rightSideNodeCenter;

  Offset get toPosition => to.leftSideNodeCenter;

  void calculateMidPoint() {
    if (from == to) {
      double midx = (fromPosition.dx + toPosition.dx) / 2 + 2;
      double midy = fromPosition.dy - 70;
      midPoint = Offset(midx, midy);
    } else {
      Offset controlPoint = Offset((fromPosition.dx + toPosition.dx) / 2,
          (fromPosition.dy + toPosition.dy) / 2);
      if (fromPosition.dx > toPosition.dx && fromPosition.dy < toPosition.dy) {
        midPoint = Offset(controlPoint.dx, controlPoint.dy - 100);
      } else if (fromPosition.dx > toPosition.dx &&
          fromPosition.dy > toPosition.dy) {
        midPoint = Offset(controlPoint.dx, controlPoint.dy + 100);
      } else {
        midPoint = controlPoint;
      }
    }
  }

  RRect get textRRect {
    final rect = Rect.fromCenter(center: midPoint, width: 40, height: 24);
    return RRect.fromRectAndRadius(rect, const Radius.circular(8));
  }

  void updateSymbols(Set<String> newSymbols) {
    symbol = newSymbols;
    notifyListeners();
  }

  void setHighlight(bool value) {
    isHighlighted = value;
    notifyListeners();
  }
}
