import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:myapp/classes/node_class.dart';
import 'package:myapp/classes/transmition_class.dart';
import 'package:myapp/pages/widgets/transition_symbol_popup.dart';

class Automaton extends ChangeNotifier {
  List<Node> nodes = [];
  List<Transition> transitions = [];
  Transition? tempTransition;
  String regularExp = '';
  Offset? currentMousePosition;
  List<String> alphabet = [];

  void setAlphabet(List<String> newAlphabet) {
    alphabet = newAlphabet;
    notifyListeners();
  }

  List<String> getAlphabet() {
    return alphabet;
  }

  void setRegularExpression(String regex) {
    regularExp = regex;
    notifyListeners();
  }

  String getRegularExpression() {
    return regularExp;
  }

  void addNode(Node node) {
    if (nodes.isEmpty) {
      node.isStart = true;
    } else {
      node.isStart = false;
    }
    nodes.add(node);
    notifyListeners();
  }

  void removeNode() {
    if (nodes.isNotEmpty) {
      Node nodeToDelete = nodes.last;
      transitions.removeWhere((transition) =>
          transition.from == nodeToDelete || transition.to == nodeToDelete);
      nodes.removeLast();
      notifyListeners();
      if (kDebugMode) {
        print(
            'Deleted node: ${nodeToDelete.name} and its associated transitions');
      }
    } else {
      if (kDebugMode) {
        print('No nodes to delete');
      }
    }
  }

  Node? findNodeAtPosition(Offset position) {
    for (var node in nodes) {
      if ((position - node.leftSideNode).distance <= 30) {
        return node;
      }
    }
    return null;
  }

  void startTransition(Node fromNode, Offset fromOffset) {
    tempTransition = Transition(from: fromNode, to: fromNode, symbol: {});
    notifyListeners();
  }

  void updateTransition(Offset currentOffset) {
    currentMousePosition = currentOffset;
    notifyListeners();
  }

  Future<void> endTransition(
      Node node, Offset currentOffset, BuildContext context) async {
    if (tempTransition != null) {
      Node? targetNode = findNodeAtPosition(currentOffset);
      if (targetNode != null) {
        tempTransition!.to = targetNode;

        // Check if a transition already exists between these nodes
        Transition? existingTransition;
        for (var t in transitions) {
          if (t.from == tempTransition!.from && t.to == targetNode) {
            existingTransition = t;
            break;
          }
        }

        final Set<String>? result = await showDialog<Set<String>>(
          context: context,
          builder: (BuildContext context) {
            return TransitionSymbolPopup(
              alphabet: alphabet.join(),
              initialSymbols: existingTransition?.symbol ?? {},
            );
          },
        );

        if (result != null && result.isNotEmpty) {
          if (existingTransition != null) {
            // Update existing transition
            existingTransition.updateSymbols(result);
          } else {
            // Create new transition
            Transition newTransition = Transition(
              from: tempTransition!.from,
              to: targetNode,
              symbol: result,
            );
            transitions.add(newTransition);
          }
          notifyListeners();
        }
      }

      // Clear temporary transition and mouse position
      tempTransition = null;
      currentMousePosition = null;
      notifyListeners();
    }
  }

  int getStartStateIndex() {
    return nodes.indexWhere((node) => node.isStart);
  }

  Set<int> getAcceptingStateIndices() {
    Set<int> acceptingStates = {};
    for (int i = 0; i < nodes.length; i++) {
      if (nodes[i].isAccepting) {
        acceptingStates.add(i);
      }
    }
    return acceptingStates;
  }
}
