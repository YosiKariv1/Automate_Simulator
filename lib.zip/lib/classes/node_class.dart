import 'package:flutter/material.dart';

class Node extends ChangeNotifier {
  String name;
  bool isAccepting;
  bool isStart;
  Offset position;
  double nodeSize = 60;
  double smallCircleSize = 20;
  bool isHighlighted = false;

  Node(
      {required this.name,
      this.isAccepting = false,
      required this.position,
      this.isStart = false});

  void updatePosition(Offset newPosition) {
    position = newPosition;
    notifyListeners();
  }

  void toggleAcceptingState() {
    isAccepting = !isAccepting;
    notifyListeners();
  }

  void setHighlight(bool value) {
    isHighlighted = value;
    notifyListeners();
  }

  Offset get leftSideNode => Offset(
      position.dx - nodeSize / 2 + smallCircleSize,
      position.dy + nodeSize / 2 - smallCircleSize / 2);

  Offset get rightSideNode => Offset(
      position.dx + nodeSize - smallCircleSize / 2,
      position.dy + nodeSize / 2 - smallCircleSize / 2);

  Offset get leftSideNodeCenter => Offset(leftSideNode.dx + smallCircleSize / 2,
      leftSideNode.dy + smallCircleSize / 2);

  Offset get rightSideNodeCenter => Offset(
      rightSideNode.dx + smallCircleSize / 2,
      rightSideNode.dy + smallCircleSize / 2);

  Offset get nodeCenter =>
      Offset(position.dx + nodeSize / 2, position.dy + nodeSize / 2);
}
