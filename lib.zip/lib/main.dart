import 'package:flutter/material.dart';
import 'package:myapp/pages/home_page.dart';
import 'package:myapp/classes/automaton_class.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const DFASimulatorApp());
}

class DFASimulatorApp extends StatelessWidget {
  const DFASimulatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => Automaton(),
      child: const MaterialApp(
        home: HomePage(),
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}
