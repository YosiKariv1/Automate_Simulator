import 'package:flutter/material.dart';
import 'package:myapp/classes/automaton_class.dart';
import 'package:myapp/classes/transmition_class.dart';
import 'package:myapp/pages/widgets/transition_symbol_popup.dart';
import 'package:myapp/transition_painter.dart';
import 'package:provider/provider.dart';

class TransitionWidget extends StatelessWidget {
  const TransitionWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<Automaton>(
      builder: (context, automaton, child) {
        return Stack(
          children: [
            CustomPaint(
              size: Size.infinite,
              painter: TransitionPainter(
                transitions: automaton.transitions,
                tempTransition: automaton.tempTransition,
                currentMousePosition: automaton.currentMousePosition,
              ),
            ),
            ...automaton.transitions.map((transition) {
              return ChangeNotifierProvider.value(
                value: transition,
                child: Consumer<Transition>(
                  builder: (context, transition, child) {
                    return Positioned.fromRect(
                      rect: transition.textRRect.outerRect,
                      child: GestureDetector(
                        onTap: () => _showEditTransitionDialog(
                            context, transition, automaton.alphabet.join()),
                        child: buildTransitionContainer(
                            transition.symbol.join(',')),
                      ),
                    );
                  },
                ),
              );
            }),
          ],
        );
      },
    );
  }

  Future<void> _showEditTransitionDialog(
      BuildContext context, Transition transition, String alphabet) async {
    final result = await showDialog<Set<String>>(
      context: context,
      builder: (BuildContext context) {
        return TransitionSymbolPopup(
          alphabet: alphabet,
          initialSymbols: transition.symbol,
        );
      },
    );

    if (result != null) {
      transition.updateSymbols(result);
    }
  }

  Widget buildTransitionContainer(String label) {
    bool isHovered = false;

    return StatefulBuilder(
      builder: (context, setState) {
        return MouseRegion(
          onEnter: (_) {
            setState(() {
              isHovered = true;
            });
          },
          onExit: (_) {
            setState(() {
              isHovered = false;
            });
          },
          child: IntrinsicWidth(
            child: Container(
              constraints: const BoxConstraints(
                minWidth: 40,
                maxWidth: 120,
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: isHovered ? Colors.deepPurpleAccent : Colors.indigo,
                  width: 2,
                ),
              ),
              child: Center(
                child: buildTransitionText(label),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget buildTransitionText(String label) {
    return Text(
      label,
      style: const TextStyle(
        color: Colors.black,
        fontSize: 12,
        fontWeight: FontWeight.bold,
      ),
    );
  }
}
