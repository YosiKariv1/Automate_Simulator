import 'package:flutter/material.dart';
import 'package:myapp/classes/automaton_class.dart';
import 'package:myapp/classes/node_class.dart';
import 'package:provider/provider.dart';

class NodeWidget extends StatelessWidget {
  const NodeWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<Node>(
      builder: (context, node, child) {
        Offset localPosition = Offset.zero;
        Automaton automaton = Provider.of<Automaton>(context, listen: false);

        return Stack(
          children: [
            Positioned(
              left: node.position.dx,
              top: node.position.dy,
              child: GestureDetector(
                onPanUpdate: (details) {
                  final newPosition = node.position + details.delta;
                  node.updatePosition(newPosition);
                },
                onDoubleTap: () {
                  node.toggleAcceptingState();
                  automaton.notifyListeners();
                },
                child: buildNode(node, node.nodeSize),
              ),
            ),
            Positioned(
              left: node.leftSideNode.dx,
              top: node.leftSideNode.dy,
              child: buildSideCircle(node.smallCircleSize),
            ),
            Positioned(
              left: node.rightSideNode.dx,
              top: node.rightSideNode.dy,
              child: GestureDetector(
                onPanStart: (details) {
                  RenderBox renderBox = context.findRenderObject() as RenderBox;
                  Offset localPosition =
                      renderBox.globalToLocal(details.globalPosition);
                  automaton.startTransition(node, localPosition);
                },
                onPanUpdate: (details) {
                  RenderBox renderBox = context.findRenderObject() as RenderBox;
                  localPosition =
                      renderBox.globalToLocal(details.globalPosition);
                  automaton.updateTransition(localPosition);
                },
                onPanEnd: (details) {
                  RenderBox renderBox = context.findRenderObject() as RenderBox;
                  localPosition =
                      renderBox.globalToLocal(details.globalPosition);
                  automaton.endTransition(node, localPosition, context);
                },
                child: buildSideCircle(node.smallCircleSize),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget buildNode(Node node, double size) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: node.isHighlighted
            ? Colors.indigo[700]
            : const Color.fromARGB(255, 135, 203, 46),
        shape: BoxShape.circle,
        border: Border.all(
          color: (node.isAccepting ? Colors.black : Colors.transparent),
          width: 4,
        ),
      ),
      child: Center(
        child: Text(
          node.name,
          style: TextStyle(
            fontSize: 22,
            color: node.isHighlighted ? Colors.black : Colors.white,
            fontWeight:
                node.isHighlighted ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget buildSideCircle(double size) {
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        color: Colors.grey,
        shape: BoxShape.circle,
      ),
    );
  }
}
