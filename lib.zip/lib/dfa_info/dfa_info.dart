import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:myapp/classes/automaton_class.dart';

class DfaInfoWidget extends StatelessWidget {
  const DfaInfoWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<Automaton>(
      builder: (context, automaton, child) {
        if (automaton.nodes.isEmpty) {
          return const Center(
            child:
                Text('No DFA information available. Add nodes to see details.'),
          );
        }
        return SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildInfoCard([
                  _buildInfoRow('States (Q)',
                      automaton.nodes.map((n) => n.name).toList().join(', ')),
                  _buildInfoRow(
                      'Alphabet (Σ)',
                      automaton.getAlphabet().isEmpty
                          ? 'Not defined'
                          : automaton.getAlphabet().join(', ')),
                  _buildInfoRow('Start State (q0)', automaton.nodes.first.name),
                  _buildInfoRow(
                      'Accept States (F)', _getAcceptStates(automaton)),
                ]),
                const SizedBox(height: 24),
                _buildTransitionTable(automaton),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildInfoCard(List<Widget> content) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: content,
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }

  Widget _buildTransitionTable(Automaton automaton) {
    if (automaton.transitions.isEmpty) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Text('No transitions defined'),
        ),
      );
    }

    List<String> states = automaton.nodes.map((n) => n.name).toList();
    List<String> alphabetChars = automaton.alphabet.join().split('');

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Transition Table (δ)',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minWidth: constraints.maxWidth),
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: DataTable(
                        dataRowMinHeight: 56,
                        headingRowHeight: 64,
                        border: TableBorder.all(
                          color: Colors.grey.shade300,
                          width: 1,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        columns: [
                          DataColumn(
                            label: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.blue.shade100,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: const Text('Q/Σ',
                                  style:
                                      TextStyle(fontWeight: FontWeight.bold)),
                            ),
                          ),
                          ...alphabetChars.map((char) => DataColumn(
                                label: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: Colors.blue.shade100,
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(char,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold)),
                                ),
                              )),
                        ],
                        rows: states.map((state) {
                          return DataRow(
                            cells: [
                              DataCell(
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: Colors.grey.shade100,
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(state,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold)),
                                ),
                              ),
                              ...alphabetChars.map((char) {
                                String nextState =
                                    _getNextState(automaton, state, char);
                                return DataCell(
                                  Container(
                                    padding: const EdgeInsets.all(8),
                                    child: Text(nextState),
                                  ),
                                );
                              }),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  String _getNextState(
      Automaton automaton, String currentState, String symbol) {
    for (var transition in automaton.transitions) {
      if (transition.from.name == currentState &&
          transition.symbol.contains(symbol)) {
        return transition.to.name;
      }
    }
    return '-';
  }

  String _getAcceptStates(Automaton automaton) {
    var acceptStates =
        automaton.nodes.where((n) => n.isAccepting).map((n) => n.name).toList();
    return acceptStates.isNotEmpty ? acceptStates.join(', ') : 'None';
  }
}
