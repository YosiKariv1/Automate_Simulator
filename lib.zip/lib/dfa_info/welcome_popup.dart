import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:myapp/classes/automaton_class.dart';

class WelcomeDialog extends StatelessWidget {
  WelcomeDialog({super.key});

  final TextEditingController sigmaController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final automaton = Provider.of<Automaton>(context, listen: false);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        backgroundColor: Colors.indigo[50],
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        title: Text(
          'ברוכים הבאים לעולם האוטומטים!',
          textAlign: TextAlign.center,
          style:
              TextStyle(color: Colors.indigo[900], fontWeight: FontWeight.bold),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 20),
              Text(
                'אוטומטים הם מודלים מתמטיים המשמשים לעיבוד מידע.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.indigo[700]),
              ),
              const SizedBox(height: 20),
              Text(
                'בואו ניצור את האלפבית שלנו:',
                style: TextStyle(
                    color: Colors.indigo[900], fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: sigmaController,
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  labelText: 'הכנס את סימני האלפבית (לדוגמה: a,b,0,1)',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15.0)),
                  prefixIcon: const Icon(Icons.abc, color: Colors.indigo),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                icon: const Icon(Icons.rocket_launch, color: Colors.white),
                label: const Text('יוצאים לדרך!',
                    style: TextStyle(color: Colors.white)),
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white,
                  backgroundColor: Colors.indigo,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15.0)),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                ),
                onPressed: () {
                  String input = sigmaController.text.trim();
                  if (input.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text('האלפבית לא יכול להיות ריק!')),
                    );
                  } else {
                    // מפצל את הקלט לתווים בודדים, מסיר רווחים ודופליקטים
                    Set<String> alphabetSet = input
                        .split(',')
                        .where((e) => e.trim().isNotEmpty)
                        .toSet();
                    List<String> alphabet = alphabetSet.toList()..sort();

                    if (alphabet.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text('לא נמצאו תווים חוקיים באלפבית!')),
                      );
                    } else {
                      automaton.setAlphabet(alphabet);
                      Navigator.of(context).pop();

                      // הודעה למשתמש על האלפבית שנקבע
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                            content: Text(
                                'האלפבית נקבע: ${automaton.getAlphabet()}')),
                      );
                    }
                  }
                },
              ),
              const SizedBox(height: 20),
              Text(
                'טיפ: האלפבית מגדיר את כל הסימנים האפשריים שהאוטומט יכול לקרוא.',
                style: TextStyle(
                    color: Colors.indigo[300], fontStyle: FontStyle.italic),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

void showWelcomeDialog(BuildContext context) {
  showGeneralDialog(
    context: context,
    pageBuilder: (context, animation, secondaryAnimation) {
      return ScaleTransition(
        scale: Tween<double>(begin: 0.5, end: 1.0).animate(animation),
        child: WelcomeDialog(),
      );
    },
    transitionDuration: const Duration(milliseconds: 400),
  );
}
